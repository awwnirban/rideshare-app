var Main = artifacts.require("./Main.sol");

module.exports = function(deployer) {
  deployer.deploy(Main);
};
